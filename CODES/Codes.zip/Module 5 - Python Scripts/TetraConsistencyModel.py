import boto3
import pprint
import json
import decimal
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key, Attr

dynamodb = boto3.resource('dynamodb', region_name='ap-southeast-1')

table = dynamodb.Table('TetraMovies')

############################################################
# QUERY to get a range of item from "TetraMovies" table
############################################################

print("Movies from 1985")

response = table.query(
    KeyConditionExpression=Key('year').eq(1985),
    ProjectionExpression="title,info.actors[1]",
    ConsistentRead=True,
    ReturnConsumedCapacity='TOTAL'
)

# pprint.pprint(response['Items'])
pprint.pprint(response)