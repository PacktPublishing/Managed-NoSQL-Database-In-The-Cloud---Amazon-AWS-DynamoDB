import boto3
import json
import pprint

ddb = boto3.client('dynamodb', 'ap-southeast-1')

# Create Table with LSI and GSI

createTable = ddb.create_table(
        TableName='ProductCatalog',
        AttributeDefinitions=[
            {'AttributeName': 'Id', 'AttributeType': 'N'},
            {'AttributeName': 'Title', 'AttributeType': 'S'},
            {'AttributeName': 'ISBN', 'AttributeType': 'S'},
            {'AttributeName': 'Authors', 'AttributeType': 'S'},
            {'AttributeName': 'ZipCode', 'AttributeType': 'N'},
            {'AttributeName': 'ProductCategory', 'AttributeType': 'S'}
        ],
        KeySchema=[
            {'AttributeName': 'Id', 'KeyType': 'HASH'},
            {'AttributeName': 'Title', 'KeyType': 'RANGE'}
        ],
        ProvisionedThroughput={
                'ReadCapacityUnits': 5,
                'WriteCapacityUnits': 5
        },
        LocalSecondaryIndexes=[
            {
                'IndexName': 'ProductCatalogLSIIx1',
                'KeySchema': [
                    {'AttributeName': 'Id', 'KeyType': 'HASH'},
                    { 'AttributeName': 'ISBN', 'KeyType': 'RANGE' }
                ],
                'Projection' : {
                    'ProjectionType': 'KEYS_ONLY'
                }
            },
            {
                'IndexName': 'ProductCatalogLSIIx2',
                'KeySchema': [
                    {'AttributeName': 'Id', 'KeyType': 'HASH'},
                    {'AttributeName': 'Authors', 'KeyType': 'RANGE'}
                ],
                'Projection': {
                    'ProjectionType': 'KEYS_ONLY'
                }
            }
        ],
        GlobalSecondaryIndexes=[
            {
                'IndexName': 'ProductCatalogGSIIx1',
                'KeySchema': [
                    {
                        'AttributeName': 'ZipCode',
                        'KeyType': 'HASH'
                    },
                    {
                        'AttributeName': 'ProductCategory',
                        'KeyType': 'RANGE'
                    }
                ],
                'Projection': {
                    'ProjectionType': 'KEYS_ONLY'
                },
                'ProvisionedThroughput': {
                        'ReadCapacityUnits': 5,
                        'WriteCapacityUnits': 5
                }
            }
        ]
)

pprint.pprint(createTable)


# Update table to ADD an additional GSI

# UpdateTable = ddb.update_table(
#             TableName='ProductCatalog',
#             # ProvisionedThroughput={
#             #     'ReadCapacityUnits': 2,
#             #     'WriteCapacityUnits': 2
#             # },
#             # AttributeDefinitions=[
#             #     {
#             #         'AttributeName': 'CatalogId',
#             #         'AttributeType': 'N'
#             #     },
#             #     {
#             #         'AttributeName': 'Authors',
#             #          'AttributeType': 'S'
#             #     }
#             # ],
#             GlobalSecondaryIndexUpdates=[
#                 {
#             #         # 'Update': {
#             #         #     'IndexName': 'ProductCatalogGSIIx1',
#             #         #     'ProvisionedThroughput': {
#             #         #         'ReadCapacityUnits': 3,
#             #         #         'WriteCapacityUnits': 3
#             #         #     }
#             #         # }
#             #         'Create': {
#             #             'IndexName': 'ProductCatalogGSIIx2',
#             #             'KeySchema': [
#             #                 {
#             #                     'AttributeName': 'CatalogId',
#             #                     'KeyType': 'HASH'
#             #                 },
#             #                 {
#             #                     'AttributeName': 'Authors',
#             #                     'KeyType': 'RANGE'
#             #                 }
#             #             ],
#             #             'Projection': {
#             #                 'ProjectionType': 'KEYS_ONLY'
#             #             },
#             #             'ProvisionedThroughput': {
#             #                 'ReadCapacityUnits': 2,
#             #                 'WriteCapacityUnits': 2
#             #             }
#             #         }
#                     'Delete': {
#                         'IndexName': 'ProductCatalogGSIIx2'
#                     }
#                 }
# #             ]
# #
# # )
# pprint.pprint(UpdateTable)
#

# # Delete Table
#
# DeleteTable = ddb.delete_table(TableName='TetraDDB-Dept')
# pprint.pprint(DeleteTable)